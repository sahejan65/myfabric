/* ══════════════════════════════════════
   MYFABRIC — SHARED DATA
   js/data.js
   Products, stitching prices, config
══════════════════════════════════════ */

const PRODUCTS = [
  {id:1,  name:'Premium Cotton Shirting',   tag:'Shirt',    emoji:'👔', price:449,  per:'m', desc:'Ultra-soft combed cotton with a crisp hand-feel. Ideal for formal and casual shirts alike.',       color:'Sky Blue',    match:['Pant']},
  {id:2,  name:'Egyptian Poplin Shirt',     tag:'Shirt',    emoji:'🔵', price:399,  per:'m', desc:'Fine poplin weave with a smooth finish. Wrinkle-resistant — perfect for daily office wear.',       color:'White',       match:['Pant']},
  {id:3,  name:'Linen Chambray Shirt',      tag:'Shirt',    emoji:'🌿', price:549,  per:'m', desc:'Breathable linen-chambray blend with subtle texture. A summer essential.',                         color:'Sage Green',  match:['Pant','Kurta']},
  {id:4,  name:'Premium Wool Suiting',      tag:'Suit',     emoji:'🧥', price:1299, per:'m', desc:'Pure wool suiting fabric with a fine twill. Drapes beautifully for a polished silhouette.',       color:'Charcoal',    match:['Shirt']},
  {id:5,  name:'Terry Rayon Suiting',       tag:'Suit',     emoji:'⬜', price:999,  per:'m', desc:'Lightweight terry rayon with a natural sheen. Comfortable suiting for warmer climates.',           color:'Beige',       match:['Shirt']},
  {id:6,  name:'Cotton Pant Fabric',        tag:'Pant',     emoji:'👖', price:549,  per:'m', desc:'Hard-wearing cotton twill with a smooth finish. Ideal for chinos and formal trousers.',            color:'Khaki',       match:['Shirt','Kurta']},
  {id:7,  name:'Polyester Blend Trousers',  tag:'Pant',     emoji:'🔷', price:449,  per:'m', desc:'Crease-resistant poly-viscose blend. Holds its shape throughout the day.',                         color:'Navy',        match:['Shirt']},
  {id:8,  name:'Chanderi Silk Kurta',       tag:'Kurta',    emoji:'✨', price:799,  per:'m', desc:'Lightweight Chanderi with a silk-cotton blend. Sheer with a gold shimmer — festive excellence.',   color:'Gold',        match:['Pajama']},
  {id:9,  name:'Khadi Kurta Fabric',        tag:'Kurta',    emoji:'🌾', price:349,  per:'m', desc:'Handspun khadi with a rustic texture. Casual and breathable for everyday wear.',                   color:'Off-White',   match:['Pajama','Pant']},
  {id:10, name:'Banarasi Brocade',          tag:'Sherwani', emoji:'👑', price:1999, per:'m', desc:'Rich Banarasi brocade with zari weave. The ultimate choice for wedding sherwanis.',               color:'Maroon Gold',  match:['Pajama']},
  {id:11, name:'Velvet Sherwani',           tag:'Sherwani', emoji:'💜', price:2299, per:'m', desc:'Plush velvet with intricate embroidery borders. Regal — for the grandest occasions.',              color:'Royal Blue',  match:['Pajama']},
  {id:12, name:'Raw Silk Bandhgala',        tag:'Bandhgala',emoji:'🎩', price:1499, per:'m', desc:'Pure raw silk with natural slubs and subtle sheen. The modern Indian formal.',                     color:'Ivory',       match:['Pant']},
  {id:13, name:'Rayon Pajama Fabric',       tag:'Pajama',   emoji:'🩳', price:249,  per:'m', desc:'Soft rayon-cotton blend. Lightweight and comfortable for kurta pajama sets.',                      color:'White',       match:['Kurta']},
  {id:14, name:'Premium Irish Linen',       tag:'Shirt',    emoji:'☘️', price:649,  per:'m', desc:'Imported Irish linen with distinctive woven texture. The fabric of summer luxury.',               color:'Natural',     match:['Pant']},
  {id:15, name:'Wool Gabardine Suit',       tag:'Suit',     emoji:'⬛', price:1399, per:'m', desc:'Smooth gabardine with a tight twill weave. Wrinkle-resistant suiting for travel.',                color:'Black',       match:['Shirt']},
  {id:16, name:'Jacquard Kurta',            tag:'Kurta',    emoji:'🌸', price:599,  per:'m', desc:'Self-patterned jacquard weave in cotton-silk. Adds texture and depth without embroidery.',         color:'Pink',        match:['Pajama']},
];

/* 
  STITCHING PRICES — separate from fabric cost.
  BUG FIX vs original: Original code doubled the FABRIC price when stitching was added (price * 2).
  CORRECT: Fabric price is always fabric price. Stitching price is an ADDITIONAL separate charge.
*/
const STITCH_PRICES = {
  Shirt:     599,
  Pant:      499,
  Kurta:     799,
  Pajama:    399,
  Suit:      1499,
  Sherwani:  2499,
  Bandhgala: 1999,
  Koti:      899,
};

const CUSTOM_MEASUREMENT_FEE = 150; // extra fee for custom size (not standard)
const FREE_DELIVERY_THRESHOLD = 2000;
const STANDARD_DELIVERY_DAYS = 7;
const CUSTOM_DELIVERY_DAYS   = 14;

// Whatsapp number
const WA_NUMBER = '919173251415';
