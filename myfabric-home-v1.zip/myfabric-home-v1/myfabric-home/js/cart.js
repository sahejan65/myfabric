/* ══════════════════════════════════════
   MYFABRIC — CART & WISHLIST LOGIC
   js/cart.js

   BUG FIX: Original myfabric.html line 921:
   ₹${(item.price*(item.stitching?2:1)*item.qty)}
   This wrongly DOUBLED the FABRIC price when stitching was added.

   CORRECT LOGIC:
   - Fabric price = item.price * item.qty  (always)
   - Stitching charge = STITCH_PRICES[garment] * item.qty  (separate, only if stitching)
   - Total per item = fabric + stitching
══════════════════════════════════════ */

// ── STATE (loaded from localStorage) ──
let cart     = JSON.parse(localStorage.getItem('mf-cart')     || '[]');
let wishlist = JSON.parse(localStorage.getItem('mf-wishlist') || '[]');

// ── CART HELPERS ──

function addToCart(id, stitching = null) {
  if (stitching) {
    // Each stitching order is a unique line item (don't merge)
    const p = PRODUCTS.find(x => x.id === id);
    cart.push({
      id,
      name: p.name,
      emoji: p.emoji,
      price: p.price,
      tag: p.tag,
      qty: 1,
      stitching,                         // stitching config object
      stitchPrice: STITCH_PRICES[stitching.garment] || 599  // store separately!
    });
  } else {
    const existing = cart.find(i => i.id === id && !i.stitching);
    if (existing) {
      existing.qty++;
    } else {
      const p = PRODUCTS.find(x => x.id === id);
      cart.push({ id, name: p.name, emoji: p.emoji, price: p.price, tag: p.tag, qty: 1, stitching: null, stitchPrice: 0 });
    }
  }
  saveCart();
  showToast((stitching ? 'Stitching order' : 'Item') + ' added to cart!');
}

function removeFromCart(idx) {
  cart.splice(idx, 1);
  saveCart();
  if (typeof renderCart === 'function') renderCart();
}

function updateQty(idx, delta) {
  cart[idx].qty = Math.max(1, cart[idx].qty + delta);
  saveCart();
  if (typeof renderCart === 'function') renderCart();
}

function saveCart() {
  localStorage.setItem('mf-cart', JSON.stringify(cart));
  updateCartBadge();
}

function updateCartBadge() {
  const total = cart.reduce((s, i) => s + i.qty, 0);
  const badge = document.getElementById('cart-count');
  if (badge) {
    badge.textContent = total;
    badge.style.display = total > 0 ? 'flex' : 'none';
  }
}

/**
 * Calculate correct item total:
 * fabric price + stitching price (if any) × qty
 */
function itemTotal(item) {
  const fabric   = item.price;
  const stitch   = item.stitching ? (item.stitchPrice || STITCH_PRICES[item.stitching.garment] || 0) : 0;
  return (fabric + stitch) * item.qty;
}

/**
 * Build WhatsApp order message
 */
function buildWhatsAppMsg() {
  const lines = cart.map(i => {
    const total = itemTotal(i);
    let line = `• ${i.name} ×${i.qty} (Fabric: ₹${i.price}/m) = ₹${(i.price * i.qty).toLocaleString()}`;
    if (i.stitching) {
      const sp = i.stitchPrice || STITCH_PRICES[i.stitching.garment] || 0;
      line += `\n  + Stitching (${i.stitching.garment}, ${i.stitching.size}, ${i.stitching.fit || 'Regular'}) = ₹${(sp * i.qty).toLocaleString()}`;
    }
    return line;
  });
  const grandTotal = cart.reduce((s, i) => s + itemTotal(i), 0);
  return lines.join('\n') + `\n\n*Grand Total: ₹${grandTotal.toLocaleString()}*`;
}

function proceedCheckout() {
  const msg = 'Hello! I want to place an order:\n\n' + buildWhatsAppMsg();
  window.open(`https://wa.me/${WA_NUMBER}?text=${encodeURIComponent(msg)}`, '_blank');
}

// ── WISHLIST ──

function toggleWishlist(id, btn) {
  const idx = wishlist.indexOf(id);
  if (idx > -1) {
    wishlist.splice(idx, 1);
    if (btn) btn.classList.remove('active');
    showToast('Removed from wishlist');
  } else {
    wishlist.push(id);
    if (btn) btn.classList.add('active');
    showToast('Added to wishlist! ❤️');
  }
  localStorage.setItem('mf-wishlist', JSON.stringify(wishlist));
  updateWishlistBadge();
}

function updateWishlistBadge() {
  const count = wishlist.length;
  const badge = document.getElementById('wishlist-count');
  if (badge) {
    badge.textContent = count;
    badge.style.display = count > 0 ? 'flex' : 'none';
  }
}

// ── TOAST ──
function showToast(msg) {
  const t = document.getElementById('toast');
  if (!t) return;
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.classList.remove('show'), 2800);
}

// ── INIT BADGES ──
updateCartBadge();
updateWishlistBadge();
