/* ══════════════════════════════════════
   MYFABRIC — HOME PAGE JS
   js/home.js
══════════════════════════════════════ */

// ── HEADER SCROLL ──
const siteHeader = document.getElementById('site-header');
window.addEventListener('scroll', () => {
  siteHeader.classList.toggle('scrolled', window.scrollY > 40);
});

// ── MOBILE MENU ──
function toggleMenu() {
  const nav = document.getElementById('mobile-nav');
  const btn = document.getElementById('hamburger-btn');
  nav.classList.toggle('open');
  btn.classList.toggle('open');
}
function closeMenu() {
  document.getElementById('mobile-nav').classList.remove('open');
  document.getElementById('hamburger-btn').classList.remove('open');
}

// ── SMOOTH SCROLL TO SECTION ──
function scrollToSection(id) {
  const el = document.getElementById(id);
  if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// ── TRENDING GRID ──
function renderTrending() {
  const grid = document.getElementById('trending-grid');
  if (!grid) return;
  const trending = PRODUCTS.slice(0, 6); // first 6 as trending

  grid.innerHTML = trending.map(p => `
    <div class="product-card" onclick="openProductModal(${p.id})">
      <div class="product-card-img">
        <div class="texture"></div>
        <span>${p.emoji}</span>
        <button class="wishlist-btn ${wishlist.includes(p.id) ? 'active' : ''}"
          onclick="event.stopPropagation(); toggleWishlist(${p.id}, this)">
          <svg viewBox="0 0 24 24"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
        </button>
      </div>
      <div class="product-card-info">
        <div class="product-tag">${p.tag} Fabric</div>
        <div class="product-name">${p.name}</div>
        <div class="product-color">${p.color}</div>
        <div class="product-footer">
          <div class="product-price">₹${p.price} <span>/ ${p.per}</span></div>
          <button class="add-btn" onclick="event.stopPropagation(); addToCart(${p.id})">+ Cart</button>
        </div>
      </div>
    </div>
  `).join('');
}

// ── PRODUCT MODAL ──
let currentModal = null;

function openProductModal(id) {
  const p = PRODUCTS.find(x => x.id === id);
  if (!p) return;
  currentModal = p;

  document.getElementById('m-img').textContent  = p.emoji;
  document.getElementById('m-tag').textContent  = p.tag + ' Fabric';
  document.getElementById('m-name').textContent = p.name;
  document.getElementById('m-price').textContent = '₹' + p.price + ' / ' + p.per;
  document.getElementById('m-desc').textContent = p.desc;

  const chipsWrap = document.getElementById('m-chips-wrap');
  const chips     = document.getElementById('m-chips');
  if (p.match && p.match.length) {
    chipsWrap.style.display = 'block';
    chips.innerHTML = p.match.map(m =>
      `<a class="chip" href="products.html?cat=${m}">${m} Fabric →</a>`
    ).join('');
  } else {
    chipsWrap.style.display = 'none';
  }

  document.getElementById('product-modal').classList.add('active');
  document.body.style.overflow = 'hidden';
}

function closeProductModal() {
  document.getElementById('product-modal').classList.remove('active');
  document.body.style.overflow = '';
  currentModal = null;
}

function addFromModal() {
  if (currentModal) {
    addToCart(currentModal.id);
    closeProductModal();
  }
}

// ── SEARCH ──
function toggleSearch() {
  const el = document.getElementById('search-overlay');
  el.classList.toggle('active');
  if (el.classList.contains('active')) {
    document.getElementById('search-input').focus();
    document.body.style.overflow = 'hidden';
  } else {
    document.getElementById('search-input').value = '';
    document.getElementById('search-results').innerHTML = '<p class="search-hint">Type to search our collection…</p>';
    document.body.style.overflow = '';
  }
}

function doSearch(q) {
  const results = document.getElementById('search-results');
  if (!q.trim()) {
    results.innerHTML = '<p class="search-hint">Type to search our collection…</p>';
    return;
  }
  const found = PRODUCTS.filter(p =>
    p.name.toLowerCase().includes(q.toLowerCase()) ||
    p.tag.toLowerCase().includes(q.toLowerCase())  ||
    p.color.toLowerCase().includes(q.toLowerCase())
  );
  if (!found.length) {
    results.innerHTML = `<p class="search-hint">No results found for "${q}"</p>`;
    return;
  }
  results.innerHTML = found.map(p => `
    <div class="product-card" onclick="toggleSearch(); openProductModal(${p.id})" style="cursor:pointer">
      <div class="product-card-img" style="height:160px">
        <span style="font-size:3rem">${p.emoji}</span>
      </div>
      <div class="product-card-info">
        <div class="product-tag">${p.tag}</div>
        <div class="product-name" style="font-size:14px">${p.name}</div>
        <div class="product-price" style="margin-top:0.5rem">₹${p.price}<span>/m</span></div>
      </div>
    </div>
  `).join('');
}

// ── CONTACT FORM ──
function submitContact(e) {
  e.preventDefault();
  const btn = document.getElementById('contact-btn');
  btn.textContent = 'Sending…';
  btn.disabled = true;
  setTimeout(() => {
    btn.textContent = 'Message Sent ✓';
    btn.style.background = '#8A9E7E';
    setTimeout(() => {
      btn.textContent = 'Send Message';
      btn.style.background = '';
      btn.disabled = false;
      e.target.reset();
    }, 3000);
  }, 1200);
}

// ── NEWSLETTER ──
function subscribeNewsletter(btn) {
  btn.textContent = 'Subscribed ✓';
  btn.style.background = '#8A9E7E';
  setTimeout(() => {
    btn.textContent = 'Subscribe';
    btn.style.background = '';
  }, 3000);
}

// ── SCROLL REVEAL ──
const revealObserver = new IntersectionObserver(entries => {
  entries.forEach(e => {
    if (e.isIntersecting) {
      e.target.classList.add('in');
      revealObserver.unobserve(e.target);
    }
  });
}, { threshold: 0.08 });

document.querySelectorAll('.reveal').forEach(el => revealObserver.observe(el));

// ── CLOSE ON ESCAPE & OUTSIDE CLICK ──
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    closeProductModal();
    const so = document.getElementById('search-overlay');
    if (so && so.classList.contains('active')) toggleSearch();
    closeMenu();
  }
});

document.getElementById('product-modal').addEventListener('click', function(e) {
  if (e.target === this) closeProductModal();
});

// ── INIT ──
renderTrending();
