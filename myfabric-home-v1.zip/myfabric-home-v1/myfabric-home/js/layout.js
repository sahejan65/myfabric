/* ══════════════════════════════════════
   MYFABRIC — SHARED LAYOUT INJECTOR
   js/layout.js
   Injects header + footer into every page.
   Call injectLayout(activePage) at top of each page's JS.
   activePage: 'home'|'products'|'stitching'|'cart'|'wishlist'|'login'
══════════════════════════════════════ */

function injectHeader(activePage) {
  const nav = ['home','products','stitching'].map(p => {
    const labels = { home:'Home', products:'Fabrics', stitching:'Stitching' };
    const hrefs  = { home:'index.html', products:'products.html', stitching:'stitching.html' };
    return `<a href="${hrefs[p]}" class="${activePage===p?'active':''}">${labels[p]}</a>`;
  }).join('');

  document.getElementById('site-header-mount').innerHTML = `
    <div class="ann">Free delivery above ₹2000 &nbsp;|&nbsp; <span>FABRIC10 for 10% off</span> &nbsp;|&nbsp; Mon–Sat 10am–8pm</div>
    <header id="site-header">
      <div class="hdr">
        <a class="logo" href="index.html">
          <div class="logo-icon">
            <svg viewBox="0 0 26 26" fill="none"><path d="M3 13h20M13 3v20M6 6l14 14M20 6L6 20" stroke="#C9A84C" stroke-width="1.4" stroke-linecap="round"/></svg>
          </div>
          <div>
            <div class="logo-fabric">My<span class="dot">Fabric</span></div>
            <div class="logo-sub">Ahmedabad · Est. 2018</div>
          </div>
        </a>
        <nav>${nav}
          <a href="#" onclick="scrollToSection('about'); return false;" class="${activePage==='about'?'active':''}">About</a>
          <a href="#" onclick="scrollToSection('contact'); return false;" class="${activePage==='contact'?'active':''}">Contact</a>
        </nav>
        <div class="hdr-actions">
          <button class="ico" onclick="toggleSearch()" title="Search">
            <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
          </button>
          <a class="ico" href="wishlist.html" title="Wishlist" style="text-decoration:none;position:relative">
            <svg viewBox="0 0 24 24"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
            <span class="cart-badge" id="wishlist-count" style="display:none">0</span>
          </a>
          <a class="ico" href="cart.html" title="Cart" style="text-decoration:none;position:relative">
            <svg viewBox="0 0 24 24"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
            <span class="cart-badge" id="cart-count" style="display:none">0</span>
          </a>
          <a class="btn-nav" href="login.html">Login</a>
          <button class="hamburger" id="hamburger-btn" onclick="toggleMobileMenu()">
            <span></span><span></span><span></span>
          </button>
        </div>
      </div>
    </header>
    <div class="mobile-nav" id="mobile-nav">
      <a href="index.html">Home</a>
      <a href="products.html">Fabrics</a>
      <a href="stitching.html">Stitching</a>
      <a href="cart.html">Cart</a>
      <a href="wishlist.html">Wishlist</a>
      <button class="m-cta" onclick="window.location='login.html'">Login / Register</button>
    </div>
  `;

  // Scroll behaviour
  const hdr = document.getElementById('site-header');
  window.addEventListener('scroll', () => hdr && hdr.classList.toggle('scrolled', window.scrollY > 40));
}

function injectFooter() {
  const el = document.getElementById('site-footer-mount');
  if (!el) return;
  el.innerHTML = `
    <footer class="site-footer">
      <div class="con">
        <div class="footer-grid">
          <div class="footer-brand">
            <div class="logo" style="margin-bottom:1rem">
              <div class="logo-icon" style="width:36px;height:36px">
                <svg viewBox="0 0 26 26" fill="none"><path d="M3 13h20M13 3v20M6 6l14 14M20 6L6 20" stroke="#C9A84C" stroke-width="1.4" stroke-linecap="round"/></svg>
              </div>
              <div>
                <div class="logo-fabric" style="font-size:20px">My<span class="dot">Fabric</span></div>
                <div class="logo-sub">Ahmedabad · Est. 2018</div>
              </div>
            </div>
            <p style="color:rgba(255,255,255,0.45);font-size:13px;line-height:1.8;max-width:260px">Premium unstitched fabrics & custom stitching for every occasion.</p>
          </div>
          <div class="footer-links">
            <h5>Quick Links</h5>
            <a href="index.html">Home</a>
            <a href="products.html">All Fabrics</a>
            <a href="stitching.html">Stitching</a>
            <a href="cart.html">Cart</a>
            <a href="wishlist.html">Wishlist</a>
            <a href="login.html">Login</a>
          </div>
          <div class="footer-links">
            <h5>Fabric Types</h5>
            <a href="products.html?cat=Shirt">Shirt</a>
            <a href="products.html?cat=Pant">Pant</a>
            <a href="products.html?cat=Kurta">Kurta</a>
            <a href="products.html?cat=Suit">Suit</a>
            <a href="products.html?cat=Sherwani">Sherwani</a>
            <a href="products.html?cat=Bandhgala">Bandhgala</a>
          </div>
          <div class="footer-links">
            <h5>Contact</h5>
            <a href="tel:+919173251415">+91 91732 51415</a>
            <a href="mailto:hello@myfabric.in">hello@myfabric.in</a>
            <a href="#">Satellite, Ahmedabad</a>
            <div class="footer-hours">Mon–Sat: 10am–8pm</div>
            <div class="newsletter-wrap">
              <input type="email" placeholder="Your email" class="newsletter-input">
              <button class="newsletter-btn" onclick="subscribeNewsletter(this)">Subscribe</button>
            </div>
          </div>
        </div>
        <div class="footer-bottom">
          <span>© 2025 MyFabric. All rights reserved. Made with ❤️ in Ahmedabad.</span>
          <span style="color:rgba(255,255,255,0.3)">Privacy Policy &nbsp;·&nbsp; Terms</span>
        </div>
      </div>
    </footer>
  `;
}

/* ── Shared mobile menu toggle ── */
function toggleMobileMenu() {
  const nav = document.getElementById('mobile-nav');
  const btn = document.getElementById('hamburger-btn');
  if (!nav) return;
  nav.classList.toggle('open');
  if (btn) btn.classList.toggle('open');
}

/* ── Scroll to section (for footer links) ── */
function scrollToSection(id) {
  const el = document.getElementById(id);
  if (el) el.scrollIntoView({ behavior: 'smooth' });
}

/* ── Newsletter ── */
function subscribeNewsletter(btn) {
  btn.textContent = 'Subscribed ✓';
  btn.style.background = '#8A9E7E';
  setTimeout(() => { btn.textContent = 'Subscribe'; btn.style.background = ''; }, 3000);
}

/* ── Search overlay (shared) ── */
function toggleSearch() {
  const el = document.getElementById('search-overlay');
  if (!el) return;
  el.classList.toggle('active');
  if (el.classList.contains('active')) {
    document.getElementById('search-input')?.focus();
    document.body.style.overflow = 'hidden';
  } else {
    document.body.style.overflow = '';
  }
}

function doSearch(q) {
  const results = document.getElementById('search-results');
  if (!results) return;
  if (!q.trim()) { results.innerHTML = '<p class="search-hint">Type to search our collection…</p>'; return; }
  const found = PRODUCTS.filter(p =>
    p.name.toLowerCase().includes(q.toLowerCase()) ||
    p.tag.toLowerCase().includes(q.toLowerCase()) ||
    p.color.toLowerCase().includes(q.toLowerCase())
  );
  if (!found.length) { results.innerHTML = `<p class="search-hint">No results for "${q}"</p>`; return; }
  results.innerHTML = found.map(p => `
    <div class="product-card" onclick="window.location='product-detail.html?id=${p.id}'" style="cursor:pointer">
      <div class="product-card-img" style="height:140px"><span style="font-size:2.5rem">${p.emoji}</span></div>
      <div class="product-card-info">
        <div class="product-tag">${p.tag}</div>
        <div class="product-name" style="font-size:14px">${p.name}</div>
        <div class="product-price" style="margin-top:0.5rem;font-size:14px">₹${p.price}<span>/m</span></div>
      </div>
    </div>
  `).join('');
}